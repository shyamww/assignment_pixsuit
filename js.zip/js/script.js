function generate() {

  var doc = new jsPDF('p', 'pt');

  var res = doc.autoTableHtmlToJson(document.getElementById("basic-table"));
  doc.autoTable(res.columns, res.data, {margin: {top: 80}});

  var header = function(data) {
    doc.setFontSize(18);
    doc.setTextColor(40);
    doc.setFontStyle('normal');
    doc.text("Testing Report", data.settings.margin.center, 50);
  };

  var options = {
    beforePageContent: header,
    margin: {
      top: 80
    },
    startY: doc.autoTableEndPosY() + 20
  };

  doc.autoTable(res.columns, res.data, options);

  doc.save("table.pdf");
}

var comapnyJSON={
  IssueDate:'03/12/2019',
  Due_Date:'04/02/2019',
  Net:'21',
  Currency:'USD',
  P_O_Number:'1/3-147',
 
};
 

var invoiceJSON={
  InvoiceNo:'Slate Rock and Gravel Company ',
  RefNo:'222 Rocky Way',
  TotalAmnt:'30000 Bedrock, Cobblestone Country ',
  SubTotalAmnt:'+555 7 123-5555',
  AddressL5:'fred@slaterockgravel.bed',
  Address6:'Attn: Fred Flintstone',
  Total:'244.80',
   
}


var fontSizes={
  HeadTitleFontSize:18,
  Head2TitleFontSize:16,
  TitleFontSize:14,
  SubTitleFontSize:12,
  NormalFontSize:10,
  SmallFontSize:8
};
 
var lineSpacing={
  NormalSpacing:12,
};

function generate_customPDF() {
  
    var doc = new jsPDF('p', 'pt');
  
    var rightStartCol1=400;
    //var rightStartCol2=480;

    //var InitialstartX=40;
    var startX=40;
    var InitialstartY=250;
    var startY=250;

    //var lineHeights=12;

    var res = doc.autoTableHtmlToJson(document.getElementById("basic-table"));
      res = doc.autoTableHtmlToJson(document.getElementById("tblInvoiceItemsList"));
    
    doc.setFontSize(fontSizes.SubTitleFontSize);
 
    doc.setFontType('bold');
    doc.textAlign("Issue Date", {align: "left"}, startX, startY+=lineSpacing.NormalSpacing);
    doc.setFontType('normal');
    doc.textAlign(comapnyJSON.IssueDate, {align: "left"}, 120, startY);

    doc.setFontType('bold');
    doc.setFontSize(fontSizes.NormalFontSize);
    doc.textAlign("Due Date", {align: "left"}, startX, startY+=lineSpacing.NormalSpacing);
    doc.setFontType('normal');
    doc.textAlign(comapnyJSON.Due_Date, {align: "left"}, 120, startY);
    
    doc.setFontType('bold');
    doc.textAlign("Net", {align: "left"}, startX, startY+=lineSpacing.NormalSpacing);
    doc.setFontType('normal');
    doc.textAlign(comapnyJSON.Net, {align: "left"}, 120, startY);

    doc.setFontType('bold');
    doc.textAlign("Currency", {align: "left"}, startX, startY+=lineSpacing.NormalSpacing);
    doc.setFontType('normal');
    doc.textAlign(comapnyJSON.Currency, {align: "left"}, 120, startY);
    
    doc.setFontType('bold');
    doc.textAlign("P.O.#", {align: "left"}, startX, startY+=lineSpacing.NormalSpacing);
    doc.setFontType('normal');
    doc.textAlign(comapnyJSON.P_O_Number, {align: "left"}, 120, startY);
    

   var tempY=InitialstartY;


    doc.setFontType('normal');
    doc.textAlign("Bill to : ", {align: "left"},  rightStartCol1, tempY+=lineSpacing.NormalSpacing);
     

    doc.setFontType('bold');
    doc.textAlign(invoiceJSON.InvoiceNo, {align: "left"},  rightStartCol1, tempY+=lineSpacing.NormalSpacing);
     
    doc.setFontType('normal');
    doc.textAlign(invoiceJSON.RefNo, {align: "left"},  rightStartCol1, tempY+=lineSpacing.NormalSpacing);
     
    doc.setFontType('normal');
    doc.textAlign(invoiceJSON.TotalAmnt, {align: "left"},  rightStartCol1, tempY+=lineSpacing.NormalSpacing);
     
    
    doc.setFontType('normal');
    doc.textAlign(invoiceJSON.SubTotalAmnt , {align: "left"},  rightStartCol1, tempY+=lineSpacing.NormalSpacing);
    
    doc.setFontType('normal');
    doc.textAlign(invoiceJSON.AddressL5, {align: "left"},  rightStartCol1, tempY+=lineSpacing.NormalSpacing);
    
    doc.setFontType('normal');
    doc.textAlign(invoiceJSON.Address6, {align: "left"},  rightStartCol1, tempY+=lineSpacing.NormalSpacing);

     

    doc.setFontType('normal');
   
    doc.setLineWidth(1);
    startY=tempY+12;
     doc.line(20, startY+lineSpacing.NormalSpacing, 580, startY+lineSpacing.NormalSpacing);
     
   // var startBilling=startY;
 
 

    var header = function(data) {
      doc.setFontSize(8);
      doc.setTextColor(40);
      doc.setFontStyle('normal');
     }; 

   doc.setFontSize(8);
   doc.setFontStyle('normal');
   
    var options = {
      beforePageContent: header,
      margin: {
        top: 50 
      },
      styles: {
        overflow: 'linebreak',
        fontSize: 8,
        rowHeight: 'auto',
        columnWidth: 'auto'
      },
      columnStyles: {
        1: {columnWidth: 'auto'},
        2: {columnWidth: 'auto'},
        3: {columnWidth: 'auto'},
        4: {columnWidth: 'auto'},
        5: {columnWidth: 'auto'},
        6: {columnWidth: 'auto'},
      },
      startY: startY+=70
    };
  
    var columns = [
      {title: "Item", dataKey: "id",width: 90},
      {title: "Quantity", dataKey: "quantity",width: 40}, 
      {title: "Price", dataKey: "Rate",width: 40}, 
      {title: "GST", dataKey: "gst",width: 40}, 
      {title: "Linetotal", dataKey: "linetotal",width: 40}, 
  ];
  var rows = [
    {"id": "Forzen Brontosaurus Ribs", "quantity": "2", "Rate": "120","gst" : "2%","linetotal":"INR 240"},
  ];
 
  doc.autoTable(columns, rows, options);  
 
  //-------Invoice Footer---------------------
  var rightcol1=340;
  var rightcol2=430;

  startY=doc.autoTableEndPosY()+30;
  doc.setFontSize(fontSizes.NormalFontSize);
  
  doc.setFontType('bold');
  doc.textAlign("TOTAL: ", {align: "left"}, rightcol1, startY+=lineSpacing.NormalSpacing);
  doc.textAlign("INR "+invoiceJSON.Total, {align: "left"}, rightcol2, startY);

    doc.save("invoice.pdf");
}